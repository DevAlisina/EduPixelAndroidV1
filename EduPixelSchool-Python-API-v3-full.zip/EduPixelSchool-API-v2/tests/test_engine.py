from app.engine import (
    ResultPolicy, annual_grade, annual_result, class_summary, final_score,
    mid_grade, mid_result, personalised_message, score_component_total, student_result,
)


def test_excel_core_thresholds():
    assert final_score(36, 60) == 96
    assert final_score(None, 60) == 60
    assert final_score(36, None) is None
    assert mid_result([36, 24, 34, 30, 40, 40], None, 81) == "موفق"
    assert mid_result([10, 40], None, 81) == "تلاش بیشتر"
    assert mid_result([], None, 81) == "غایب"
    assert mid_grade([36, 24, 34, 30, 40, 40]) == "ب"
    assert mid_grade([10, 40]) == "هـ"
    assert annual_result([96, 78, 94, 90], 5, None) == "ارتقا صنف"
    assert annual_result([96, 38, 39, 90, 100], 5, None) == "مشروط"
    assert annual_result([20, 60, 70, 80], 5, None) == "مشروط"
    assert annual_result([], 185, None) == "محروم"
    assert annual_result([], 0, None, 185) == "تکرار صنف"
    assert annual_result([], 0, None, 0) == ""
    assert annual_result([100, 100], 0, "2") == "معذرتی"
    assert annual_result([100, 100], 0, "3") == "سه پارچه"
    assert annual_grade([96,78,94,90], "ارتقا صنف") == "ب"
    assert annual_grade([60,60], "ارتقا صنف") == "ج"
    assert annual_grade([50,60], "مشروط") == "د"
    assert annual_grade([], "محروم") == ""


def test_component_form_is_optional_and_independent():
    assert score_component_total({"homework": 5, "activity": 5, "oral": 10, "written": 20}) == 40
    assert score_component_total({"x": "ignore", "y": 2}) == 2
    assert score_component_total({}) is None


def test_student_result_dynamic_subjects():
    subjects = [{"id": 1, "name": "A", "order_index": 0}, {"id": 2, "name": "B", "order_index": 1}]
    result = student_result(
        subjects=subjects,
        scores={1: {"mid": 36, "annual": 60}, 2: {"mid": 24, "annual": 54}},
        attendance={"mid": {"school_days": 81}, "annual": {"absent": 5}},
        mid_status=None,
        annual_status=None,
    )
    assert len(result["subject_results"]) == 2
    assert result["final_sum"] == 174
    assert result["annual_result"] == "ارتقا صنف"
    assert result["annual_grade"] == "ب"


def test_summary_matches_workbook_shape():
    rows = [
        {"mid_result": "موفق", "annual_result": "ارتقا صنف"},
        {"mid_result": "موفق", "annual_result": "ارتقا صنف"},
        {"mid_result": "غایب", "annual_result": "محروم"},
        {"mid_result": "معذرتي", "annual_result": "معذرتی"},
        {"mid_result": "تلاش بیشتر", "annual_result": "مشروط"},
    ]
    s = class_summary(rows)
    assert s["total_enrolled"] == 5
    assert s["mid_exam_included"] == 4
    assert s["annual_exam_included"] == 4
    assert s["annual"]["ارتقا صنف"] == 2
    assert s["annual"]["محروم"] == 1
    assert s["annual"]["سه پارچه"] == 0


def test_messages():
    assert "تبریک" in personalised_message("ارتقا صنف")
    assert "تلاش" in personalised_message("تکرار صنف")
    assert personalised_message("محروم") == ""


def test_annual_empty_marks_with_school_days_repeat_and_without_blank():
    assert annual_result([], 0, None, school_days=185) == "تکرار صنف"
    assert annual_result([], 0, None, school_days=0) == ""


def test_custom_policy_changes_thresholds():
    policy = ResultPolicy(max_absence_days=10, annual_avg_pass=60, annual_min_subject=45)
    assert annual_result([55, 55, 55], 9, None, school_days=100, policy=policy) == "تکرار صنف"
    assert annual_result([50, 50, 50], 10, None, school_days=100, policy=policy) == "محروم"
