import os
os.environ["EDUPIXEL_TESTING"] = "1"

from fastapi.testclient import TestClient

from app.main import app
from app.models import reset_database

client = TestClient(app)


def setup_function():
    reset_database()


def test_full_crud_and_dynamic_subjects():
    school = client.post("/schools", json={"name":"Test School","province":"Herat","academic_year_solar":1404}).json()
    year = client.post("/academic-years", json={"school_id":school["id"],"solar_year":1404,"qamari_year":1447,"label":"1404-1447"}).json()
    cls = client.post("/classes", json={"school_id":school["id"],"academic_year_id":year["id"],"name":"سوم2","teacher_name":"Teacher"}).json()

    subjects=[]
    for i in range(7):
        subjects.append(client.post("/subjects", json={"class_id":cls["id"],"name":f"Subject {i+1}","order_index":i}).json())
    assert len(client.get(f"/classes/{cls['id']}/subjects").json()) == 7

    st = client.post("/students", json={"class_id":cls["id"],"attendance_no":1,"name":"Ali","father":"Mohammad"}).json()
    assert client.put(f"/students/{st['id']}", json={**st, "name":"Ali Sina"}).status_code == 200

    assert client.post(f"/attendance?student_id={st['id']}", json={"period":"midterm","school_days":81,"present":80,"absent":1,"sick":0,"leave":0}).status_code == 201
    assert client.post(f"/attendance?student_id={st['id']}", json={"period":"annual","school_days":185,"present":180,"absent":5,"sick":0,"leave":0}).status_code == 201

    for subj in subjects:
        r = client.post("/scores", json={"student_id":st["id"],"subject_id":subj["id"],"mid":30,"annual":60}).json()
        assert r["subject_id"] == subj["id"]
    result = client.get(f"/students/{st['id']}/result").json()
    assert result["annual_result"] == "ارتقا صنف"
    assert len(result["subject_results"]) == 7

    card = client.get(f"/students/{st['id']}/report-card").json()
    assert card["student"]["name"] == "Ali Sina"
    assert "approvals" in card

    approvals = client.post("/approvals", json={"class_id":cls["id"],"role":"هیئت 1","person_name":"Reviewer","approved":True}).json()
    assert approvals["approved"] is True
    assert len(client.get(f"/classes/{cls['id']}/approvals").json()) == 1

    dist = client.post("/book-distributions", json={"class_id":cls["id"],"student_id":st["id"],"subject_id":subjects[0]["id"],"quantity":1,"delivered":True,"signed":True}).json()
    assert dist["delivered"] is True
    register = client.get(f"/classes/{cls['id']}/book-distribution-register").json()
    assert len(register["subjects"]) == 7
    assert register["rows"][0]["subjects"][str(subjects[0]["id"])]["signed"] is True


def test_result_statuses_and_class_reports():
    school = client.post("/schools", json={"name":"S"}).json()
    cls = client.post("/classes", json={"school_id":school["id"],"name":"1A"}).json()
    sub = client.post("/subjects", json={"class_id":cls["id"],"name":"Math"}).json()

    # Student A: promoted.
    a = client.post("/students", json={"class_id":cls["id"],"attendance_no":1,"name":"A"}).json()
    client.post(f"/attendance?student_id={a['id']}", json={"period":"midterm","school_days":81,"present":81,"absent":0,"sick":0,"leave":0})
    client.post(f"/attendance?student_id={a['id']}", json={"period":"annual","school_days":185,"present":185,"absent":0,"sick":0,"leave":0})
    client.post("/scores", json={"student_id":a["id"],"subject_id":sub["id"],"mid":40,"annual":60})
    assert client.get(f"/students/{a['id']}/result").json()["annual_result"] == "ارتقا صنف"

    # Student B: banned by absence, even without scores.
    b = client.post("/students", json={"class_id":cls["id"],"attendance_no":2,"name":"B"}).json()
    client.post(f"/attendance?student_id={b['id']}", json={"period":"midterm","school_days":81,"present":0,"absent":81,"sick":0,"leave":0})
    client.post(f"/attendance?student_id={b['id']}", json={"period":"annual","school_days":185,"present":11,"absent":174,"sick":0,"leave":0})
    assert client.get(f"/students/{b['id']}/result").json()["annual_result"] == "محروم"

    report = client.get(f"/classes/{cls['id']}/results").json()
    assert report["summary"]["total_enrolled"] == 2
    assert report["summary"]["annual"]["محروم"] == 1
    assert len(client.get(f"/classes/{cls['id']}/subject-register").json()["rows"]) == 2
    assert len(client.get(f"/classes/{cls['id']}/passing-list").json()) == 1
    assert len(client.get(f"/classes/{cls['id']}/failed-or-banned-list").json()) == 1


def test_bulk_entry_policy_validation_and_dashboard():
    school = client.post("/schools", json={"name":"S2", "principal_name":"P"}).json()
    cls = client.post("/classes", json={"school_id":school["id"],"name":"3B","max_absence":5}).json()
    subjects = [
        client.post("/subjects", json={"class_id":cls["id"],"name":"S1","order_index":0,"mid_max":40,"annual_max":60}).json(),
        client.post("/subjects", json={"class_id":cls["id"],"name":"S2","order_index":1,"mid_max":20,"annual_max":80}).json(),
    ]
    a = client.post("/students", json={"class_id":cls["id"],"attendance_no":1,"name":"A"}).json()
    b = client.post("/students", json={"class_id":cls["id"],"attendance_no":2,"name":"B"}).json()

    bulk = client.post(f"/classes/{cls['id']}/scores/bulk", json={"items":[
        {"student_id":a["id"],"subject_id":subjects[0]["id"],"mid":40,"annual":60},
        {"student_id":a["id"],"subject_id":subjects[1]["id"],"mid":20,"annual":80},
    ]})
    assert bulk.status_code == 200
    assert bulk.json()["saved"] == 2

    bad = client.post("/scores", json={"student_id":a["id"],"subject_id":subjects[1]["id"],"mid":21,"annual":80})
    assert bad.status_code == 422

    att = client.post(f"/classes/{cls['id']}/attendance/bulk", json={"items":[
        {"student_id":a["id"],"period":"annual","school_days":185,"present":185,"absent":0,"sick":0,"leave":0},
        {"student_id":b["id"],"period":"annual","school_days":185,"present":100,"absent":85,"sick":0,"leave":0},
    ]})
    assert att.status_code == 200 and att.json()["saved"] == 2
    assert client.get(f"/students/{b['id']}/result").json()["annual_result"] == "محروم"

    dash = client.get(f"/classes/{cls['id']}/dashboard").json()
    assert dash["students"] == 2
    assert dash["subjects"] == 2
    assert dash["summary"]["annual"]["محروم"] == 1

    cover = client.get(f"/classes/{cls['id']}/cover").json()
    assert cover["school"]["principal_name"] == "P"
