# EduPixel School API v0.3

Backend مستقل از Excel برای بازسازی منطق واقعی فایل `صنف سوم 2.xlsx`.

**Excel در runtime اصلاً اجرا نمی‌شود.** هیچ endpointی فایل xlsx را باز نمی‌کند. منطق نمره، حاضری، نتیجه، درجه، گزارش‌ها، شقه، توزیع کتاب و تأییدها در مدل‌های Python/SQLAlchemy و موتور مستقل پیاده شده‌اند.

## پوشش سیستم

- مکتب و مشخصات مدیریتی
- سال تعلیمی شمسی/قمری
- صنف و شعبه و استاد
- سیاست نتیجه و حد محرومیت قابل تنظیم برای هر صنف
- تعداد مضامین کاملاً پویا؛ بدون وابستگی به 13 مضمون
- تعریف نمره چهارونیم‌ماهه/سالانه و سقف مستقل هر مضمون
- تعریف اجزای نمره برای فرم «شقه»
- شاگرد و مشخصات هویتی
- نمرات رسمی و اجزای نمره
- حاضری چهارونیم‌ماهه و سالانه
- موتور نتیجه/درجه و پیام شخصی
- فهرست نتایج کلاس
- فهرست مضمونوار
- فهرست جدول فشرده
- اطلاع‌نامه/کارنامه
- خلاصه آماری و داشبورد کلاس
- فهرست کامیاب، مشروط، ناکام و محروم
- پوش/جلد کلاس
- تأییدها و کارکنان بررسی
- توزیع کتاب
- CRUD کامل و endpointهای bulk برای نمره و حاضری

## API مهم

```text
GET  /health

POST /schools
POST /academic-years
POST /classes
PUT  /classes/{id}/policy

POST /subjects
GET  /classes/{id}/subjects

POST /students
GET  /classes/{id}/students

POST /scores
PUT  /scores/{id}
POST /classes/{id}/scores/bulk

POST /attendance?student_id={id}
PUT  /attendance/{id}
POST /classes/{id}/attendance/bulk

GET /students/{id}/result
GET /students/{id}/shaqah
GET /students/{id}/report-card

GET /classes/{id}/results
GET /classes/{id}/dashboard
GET /classes/{id}/subject-register
GET /classes/{id}/compact-register
GET /classes/{id}/notice-cards
GET /classes/{id}/recent-summary
GET /classes/{id}/cover
GET /classes/{id}/passing-list
GET /classes/{id}/conditional-list
GET /classes/{id}/failed-or-banned-list
GET /classes/{id}/approval-summary
GET /classes/{id}/book-distribution-register
```

Swagger: `http://127.0.0.1:8000/docs`

## اجرا

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## تست

```bash
pytest -q
python -m compileall -q app tests
```

## ساختار

```text
app/
  engine.py       # هسته مستقل از Excel
  models.py       # مدل دیتابیس
  schemas.py      # قراردادهای API
  main.py         # CRUD + گزارش‌ها

tests/
  test_engine.py
  test_api.py

EXCEL_AUDIT.md    # نگاشت شیت‌ها و قواعد استخراج‌شده
```
