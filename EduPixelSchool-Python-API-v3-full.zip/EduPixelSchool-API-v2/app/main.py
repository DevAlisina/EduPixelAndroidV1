from __future__ import annotations

import os
from typing import Any, Type

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .engine import ResultPolicy, class_summary, component_breakdown, personalised_message, score_component_total, student_result
from .models import (
    AcademicYear,
    Approval,
    Attendance,
    Base,
    BookDistribution,
    School,
    SchoolClass,
    Score,
    SessionLocal,
    Student,
    Subject,
    engine,
)
from .schemas import *

Base.metadata.create_all(bind=engine)
app = FastAPI(
    title="EduPixel School API",
    version="0.3.0",
    description="Excel-independent school management backend derived from the workbook's full workflow.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def db():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def get_or_404(session: Session, model: Type[Any], obj_id: int):
    obj = session.get(model, obj_id)
    if not obj:
        raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
    return obj


def commit_refresh(session: Session, obj):
    try:
        session.add(obj)
        session.commit()
        session.refresh(obj)
        return obj
    except IntegrityError as exc:
        session.rollback()
        raise HTTPException(status_code=409, detail="duplicate or invalid relationship") from exc


def patch_object(session: Session, obj, payload: BaseModel):
    for key, value in payload.model_dump().items():
        setattr(obj, key, value)
    return commit_refresh(session, obj)


def _school_for_class(session: Session, cls: SchoolClass) -> School:
    return get_or_404(session, School, cls.school_id)


def _class_policy(cls: SchoolClass) -> ResultPolicy:
    mapping = dict(cls.policy or {})
    # The workbook stores 56 in the class absence-threshold cell.  Keep the
    # scalar field authoritative unless the JSON policy explicitly overrides it.
    mapping.setdefault("max_absence_days", cls.max_absence)
    return ResultPolicy.from_mapping(mapping)


def _validate_score_values(subject: Subject, x: ScoreIn):
    if x.mid is not None and x.mid > subject.mid_max:
        raise HTTPException(status_code=422, detail=f"mid score exceeds subject maximum {subject.mid_max}")
    if x.annual is not None and x.annual > subject.annual_max:
        raise HTTPException(status_code=422, detail=f"annual score exceeds subject maximum {subject.annual_max}")


def _validate_score_relationships(session: Session, x: ScoreIn):
    student = get_or_404(session, Student, x.student_id)
    subject = get_or_404(session, Subject, x.subject_id)
    if subject.class_id != student.class_id:
        raise HTTPException(status_code=400, detail="student and subject must belong to the same class")
    _validate_score_values(subject, x)
    return student, subject


def _validate_attendance(x: AttendanceIn):
    # The workbook records separate counters; it does not force a sum formula.
    # We only reject impossible negative values (already handled by Pydantic).
    return x


def _student_engine_result(session: Session, student: Student, cls: SchoolClass) -> dict[str, Any]:
    subjects = (
        session.query(Subject)
        .filter(Subject.class_id == cls.id, Subject.active.is_(True), Subject.include_in_results.is_(True))
        .order_by(Subject.order_index, Subject.id)
        .all()
    )
    score_rows = session.query(Score).filter(Score.student_id == student.id).all()
    score_map = {
        row.subject_id: {
            "mid": row.mid,
            "annual": row.annual,
            "mid_components": row.mid_components or {},
            "annual_components": row.annual_components or {},
        }
        for row in score_rows
    }
    attendance: dict[str, Any] = {"mid": {}, "annual": {}}
    for row in session.query(Attendance).filter(Attendance.student_id == student.id).all():
        attendance[row.period] = {
            "school_days": row.school_days,
            "present": row.present,
            "absent": row.absent,
            "sick": row.sick,
            "leave": row.leave,
            "note": row.note,
        }

    result = student_result(
        subjects=[{"id": s.id, "name": s.name, "order_index": s.order_index} for s in subjects],
        scores=score_map,
        attendance=attendance,
        mid_status=student.mid_status,
        annual_status=student.annual_status,
        policy=_class_policy(cls),
    )
    result.update(
        {
            "student_id": student.id,
            "student_name": student.name,
            "attendance_no": student.attendance_no,
            "message": personalised_message(result["annual_result"], result["mid_result"]),
        }
    )
    return result


def _class_results(session: Session, cls: SchoolClass) -> list[dict[str, Any]]:
    students = (
        session.query(Student)
        .filter_by(class_id=cls.id)
        .order_by(Student.attendance_no.is_(None), Student.attendance_no, Student.id)
        .all()
    )
    return [_student_engine_result(session, st, cls) for st in students]


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "edupixel-school", "excel_runtime_dependency": "none"}


# ---------------------------------------------------------------------------
# Core CRUD: school / academic year / class
# ---------------------------------------------------------------------------
@app.post("/schools", response_model=SchoolOut, status_code=201)
def create_school(x: SchoolIn, session: Session = Depends(db)):
    return commit_refresh(session, School(**x.model_dump()))


@app.get("/schools", response_model=list[SchoolOut])
def list_schools(session: Session = Depends(db)):
    return session.query(School).order_by(School.id).all()


@app.get("/schools/{school_id}", response_model=SchoolOut)
def get_school(school_id: int, session: Session = Depends(db)):
    return get_or_404(session, School, school_id)


@app.put("/schools/{school_id}", response_model=SchoolOut)
def update_school(school_id: int, x: SchoolIn, session: Session = Depends(db)):
    return patch_object(session, get_or_404(session, School, school_id), x)


@app.delete("/schools/{school_id}")
def delete_school(school_id: int, session: Session = Depends(db)):
    obj = get_or_404(session, School, school_id)
    session.delete(obj)
    session.commit()
    return {"deleted": True, "id": school_id}


@app.post("/academic-years", response_model=AcademicYearOut, status_code=201)
def create_year(x: AcademicYearIn, session: Session = Depends(db)):
    get_or_404(session, School, x.school_id)
    return commit_refresh(session, AcademicYear(**x.model_dump()))


@app.get("/schools/{school_id}/academic-years", response_model=list[AcademicYearOut])
def list_years(school_id: int, session: Session = Depends(db)):
    get_or_404(session, School, school_id)
    return session.query(AcademicYear).filter_by(school_id=school_id).order_by(AcademicYear.solar_year.desc()).all()


@app.get("/academic-years/{year_id}", response_model=AcademicYearOut)
def get_year(year_id: int, session: Session = Depends(db)):
    return get_or_404(session, AcademicYear, year_id)


@app.put("/academic-years/{year_id}", response_model=AcademicYearOut)
def update_year(year_id: int, x: AcademicYearIn, session: Session = Depends(db)):
    get_or_404(session, School, x.school_id)
    return patch_object(session, get_or_404(session, AcademicYear, year_id), x)


@app.delete("/academic-years/{year_id}")
def delete_year(year_id: int, session: Session = Depends(db)):
    obj = get_or_404(session, AcademicYear, year_id)
    session.delete(obj)
    session.commit()
    return {"deleted": True, "id": year_id}


@app.post("/classes", response_model=ClassOut, status_code=201)
def create_class(x: ClassIn, session: Session = Depends(db)):
    get_or_404(session, School, x.school_id)
    if x.academic_year_id is not None:
        year = get_or_404(session, AcademicYear, x.academic_year_id)
        if year.school_id != x.school_id:
            raise HTTPException(400, "academic year must belong to the same school")
    policy = dict(x.policy)
    policy.setdefault("max_absence_days", x.max_absence)
    return commit_refresh(session, SchoolClass(**{**x.model_dump(exclude={"policy"}), "policy": policy}))


@app.get("/schools/{school_id}/classes", response_model=list[ClassOut])
def list_classes(school_id: int, year_id: int | None = Query(None), session: Session = Depends(db)):
    get_or_404(session, School, school_id)
    q = session.query(SchoolClass).filter_by(school_id=school_id)
    if year_id is not None:
        q = q.filter_by(academic_year_id=year_id)
    return q.order_by(SchoolClass.id).all()


@app.get("/classes/{class_id}", response_model=ClassOut)
def get_class(class_id: int, session: Session = Depends(db)):
    return get_or_404(session, SchoolClass, class_id)


@app.put("/classes/{class_id}", response_model=ClassOut)
def update_class(class_id: int, x: ClassIn, session: Session = Depends(db)):
    get_or_404(session, School, x.school_id)
    if x.academic_year_id is not None:
        year = get_or_404(session, AcademicYear, x.academic_year_id)
        if year.school_id != x.school_id:
            raise HTTPException(400, "academic year must belong to the same school")
    policy = dict(x.policy)
    policy.setdefault("max_absence_days", x.max_absence)
    obj = get_or_404(session, SchoolClass, class_id)
    data = x.model_dump()
    data["policy"] = policy
    for key, value in data.items():
        setattr(obj, key, value)
    return commit_refresh(session, obj)


@app.delete("/classes/{class_id}")
def delete_class(class_id: int, session: Session = Depends(db)):
    obj = get_or_404(session, SchoolClass, class_id)
    session.delete(obj)
    session.commit()
    return {"deleted": True, "id": class_id}


@app.get("/classes/{class_id}/policy")
def get_class_policy(class_id: int, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    return _class_policy(cls).as_dict()


@app.put("/classes/{class_id}/policy")
def set_class_policy(class_id: int, policy: dict[str, Any], session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    parsed = ResultPolicy.from_mapping(policy)
    cls.policy = parsed.as_dict()
    cls.max_absence = parsed.max_absence_days
    session.commit()
    return parsed.as_dict()


# ---------------------------------------------------------------------------
# Dynamic subjects
# ---------------------------------------------------------------------------
@app.post("/subjects", response_model=SubjectOut, status_code=201)
def create_subject(x: SubjectIn, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, x.class_id)
    return commit_refresh(session, Subject(**x.model_dump()))


@app.get("/classes/{class_id}/subjects", response_model=list[SubjectOut])
def list_subjects(class_id: int, active_only: bool = True, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, class_id)
    q = session.query(Subject).filter(Subject.class_id == class_id)
    if active_only:
        q = q.filter(Subject.active.is_(True))
    return q.order_by(Subject.order_index, Subject.id).all()


@app.get("/subjects/{subject_id}", response_model=SubjectOut)
def get_subject(subject_id: int, session: Session = Depends(db)):
    return get_or_404(session, Subject, subject_id)


@app.put("/subjects/{subject_id}", response_model=SubjectOut)
def update_subject(subject_id: int, x: SubjectIn, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, x.class_id)
    return patch_object(session, get_or_404(session, Subject, subject_id), x)


@app.delete("/subjects/{subject_id}")
def delete_subject(subject_id: int, session: Session = Depends(db)):
    obj = get_or_404(session, Subject, subject_id)
    session.delete(obj)
    session.commit()
    return {"deleted": True, "id": subject_id}


# ---------------------------------------------------------------------------
# Students
# ---------------------------------------------------------------------------
@app.post("/students", response_model=StudentOut, status_code=201)
def create_student(x: StudentIn, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, x.class_id)
    return commit_refresh(session, Student(**x.model_dump()))


@app.get("/classes/{class_id}/students", response_model=list[StudentOut])
def list_students(class_id: int, q: str | None = Query(None), session: Session = Depends(db)):
    get_or_404(session, SchoolClass, class_id)
    query = session.query(Student).filter(Student.class_id == class_id)
    if q:
        needle = f"%{q}%"
        query = query.filter((Student.name.ilike(needle)) | (Student.father.ilike(needle)) | (Student.tazkira.ilike(needle)))
    return query.order_by(Student.attendance_no.is_(None), Student.attendance_no, Student.id).all()


@app.get("/students/{student_id}", response_model=StudentOut)
def get_student(student_id: int, session: Session = Depends(db)):
    return get_or_404(session, Student, student_id)


@app.put("/students/{student_id}", response_model=StudentOut)
def update_student(student_id: int, x: StudentIn, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, x.class_id)
    return patch_object(session, get_or_404(session, Student, student_id), x)


@app.delete("/students/{student_id}")
def delete_student(student_id: int, session: Session = Depends(db)):
    obj = get_or_404(session, Student, student_id)
    session.delete(obj)
    session.commit()
    return {"deleted": True, "id": student_id}


# ---------------------------------------------------------------------------
# Scores / «شقه» component form
# ---------------------------------------------------------------------------
@app.post("/scores", response_model=ScoreOut, status_code=201)
def upsert_score(x: ScoreIn, session: Session = Depends(db)):
    _validate_score_relationships(session, x)
    obj = session.query(Score).filter_by(student_id=x.student_id, subject_id=x.subject_id).first()
    if obj is None:
        obj = Score(**x.model_dump())
        session.add(obj)
    else:
        for key, value in x.model_dump().items():
            setattr(obj, key, value)
    return commit_refresh(session, obj)


@app.post("/classes/{class_id}/scores/bulk")
def bulk_scores(class_id: int, x: ScoreBulkIn, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, class_id)
    results = []
    for item in x.items:
        student, subject = _validate_score_relationships(session, item)
        if student.class_id != class_id or subject.class_id != class_id:
            raise HTTPException(400, "all score items must belong to the requested class")
        obj = session.query(Score).filter_by(student_id=item.student_id, subject_id=item.subject_id).first()
        if obj is None:
            obj = Score(**item.model_dump())
            session.add(obj)
        else:
            for key, value in item.model_dump().items():
                setattr(obj, key, value)
        results.append(obj)
    try:
        session.commit()
        for obj in results:
            session.refresh(obj)
    except IntegrityError as exc:
        session.rollback()
        raise HTTPException(409, "bulk score save failed") from exc
    return {"saved": len(results), "items": [ScoreOut.model_validate(o).model_dump() for o in results]}


@app.get("/students/{student_id}/scores", response_model=list[ScoreOut])
def list_scores(student_id: int, session: Session = Depends(db)):
    get_or_404(session, Student, student_id)
    return session.query(Score).filter_by(student_id=student_id).join(Subject).order_by(Subject.order_index, Subject.id).all()


@app.get("/scores/{score_id}", response_model=ScoreOut)
def get_score(score_id: int, session: Session = Depends(db)):
    return get_or_404(session, Score, score_id)


@app.put("/scores/{score_id}", response_model=ScoreOut)
def update_score(score_id: int, x: ScoreIn, session: Session = Depends(db)):
    _validate_score_relationships(session, x)
    obj = get_or_404(session, Score, score_id)
    return patch_object(session, obj, x)


@app.delete("/scores/{score_id}")
def delete_score(score_id: int, session: Session = Depends(db)):
    obj = get_or_404(session, Score, score_id)
    session.delete(obj)
    session.commit()
    return {"deleted": True, "id": score_id}


@app.get("/scores/{score_id}/components")
def score_components(score_id: int, session: Session = Depends(db)):
    score = get_or_404(session, Score, score_id)
    return {
        "score_id": score.id,
        "student_id": score.student_id,
        "subject_id": score.subject_id,
        "mid": component_breakdown(score.mid_components),
        "annual": component_breakdown(score.annual_components),
        "official_mid": score.mid,
        "official_annual": score.annual,
    }


@app.get("/students/{student_id}/shaqah")
def shaqah_form(student_id: int, session: Session = Depends(db)):
    student = get_or_404(session, Student, student_id)
    subjects = session.query(Subject).filter(Subject.class_id == student.class_id, Subject.active.is_(True)).order_by(Subject.order_index, Subject.id).all()
    rows = []
    for subject in subjects:
        score = session.query(Score).filter_by(student_id=student.id, subject_id=subject.id).first()
        rows.append(
            {
                "subject": SubjectOut.model_validate(subject).model_dump(),
                "score_id": score.id if score else None,
                "mid_components": score.mid_components if score else {},
                "annual_components": score.annual_components if score else {},
                "mid_component_total": score_component_total(score.mid_components if score else {}),
                "annual_component_total": score_component_total(score.annual_components if score else {}),
                "official_mid": score.mid if score else None,
                "official_annual": score.annual if score else None,
            }
        )
    return {"student": StudentOut.model_validate(student).model_dump(), "subjects": rows}


# ---------------------------------------------------------------------------
# Attendance
# ---------------------------------------------------------------------------
@app.post("/attendance", response_model=AttendanceOut, status_code=201)
def upsert_attendance(student_id: int, x: AttendanceIn, session: Session = Depends(db)):
    get_or_404(session, Student, student_id)
    _validate_attendance(x)
    obj = session.query(Attendance).filter_by(student_id=student_id, period=x.period).first()
    if obj is None:
        obj = Attendance(student_id=student_id, **x.model_dump())
        session.add(obj)
    else:
        for key, value in x.model_dump().items():
            setattr(obj, key, value)
    return commit_refresh(session, obj)


@app.post("/classes/{class_id}/attendance/bulk")
def bulk_attendance(class_id: int, x: AttendanceBulkIn, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, class_id)
    saved = []
    for item in x.items:
        student = get_or_404(session, Student, item.student_id)
        if student.class_id != class_id:
            raise HTTPException(400, "all attendance items must belong to the requested class")
        obj = session.query(Attendance).filter_by(student_id=item.student_id, period=item.period).first()
        data = item.model_dump(exclude={"student_id"})
        if obj is None:
            obj = Attendance(student_id=item.student_id, **data)
            session.add(obj)
        else:
            for key, value in data.items():
                setattr(obj, key, value)
        saved.append(obj)
    session.commit()
    for obj in saved:
        session.refresh(obj)
    return {"saved": len(saved), "items": [AttendanceOut.model_validate(o).model_dump() for o in saved]}


@app.get("/students/{student_id}/attendance", response_model=list[AttendanceOut])
def list_attendance(student_id: int, session: Session = Depends(db)):
    get_or_404(session, Student, student_id)
    return session.query(Attendance).filter_by(student_id=student_id).order_by(Attendance.period).all()


@app.put("/attendance/{attendance_id}", response_model=AttendanceOut)
def update_attendance(attendance_id: int, x: AttendanceIn, session: Session = Depends(db)):
    return patch_object(session, get_or_404(session, Attendance, attendance_id), x)


@app.delete("/attendance/{attendance_id}")
def delete_attendance(attendance_id: int, session: Session = Depends(db)):
    obj = get_or_404(session, Attendance, attendance_id)
    session.delete(obj)
    session.commit()
    return {"deleted": True, "id": attendance_id}


# ---------------------------------------------------------------------------
# Administrative approvals and book distribution
# ---------------------------------------------------------------------------
@app.post("/approvals", response_model=ApprovalOut, status_code=201)
def create_approval(x: ApprovalIn, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, x.class_id)
    return commit_refresh(session, Approval(**x.model_dump()))


@app.get("/classes/{class_id}/approvals", response_model=list[ApprovalOut])
def list_approvals(class_id: int, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, class_id)
    return session.query(Approval).filter_by(class_id=class_id).order_by(Approval.id).all()


@app.put("/approvals/{approval_id}", response_model=ApprovalOut)
def update_approval(approval_id: int, x: ApprovalIn, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, x.class_id)
    return patch_object(session, get_or_404(session, Approval, approval_id), x)


@app.delete("/approvals/{approval_id}")
def delete_approval(approval_id: int, session: Session = Depends(db)):
    obj = get_or_404(session, Approval, approval_id)
    session.delete(obj)
    session.commit()
    return {"deleted": True, "id": approval_id}


@app.post("/book-distributions", response_model=DistributionOut, status_code=201)
def upsert_distribution(x: DistributionIn, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, x.class_id)
    student = get_or_404(session, Student, x.student_id)
    subject = get_or_404(session, Subject, x.subject_id)
    if student.class_id != cls.id or subject.class_id != cls.id:
        raise HTTPException(400, "all distribution references must belong to the same class")
    obj = session.query(BookDistribution).filter_by(student_id=x.student_id, subject_id=x.subject_id).first()
    if obj is None:
        obj = BookDistribution(**x.model_dump())
        session.add(obj)
    else:
        for key, value in x.model_dump().items():
            setattr(obj, key, value)
    return commit_refresh(session, obj)


@app.get("/classes/{class_id}/book-distributions", response_model=list[DistributionOut])
def list_distributions(class_id: int, session: Session = Depends(db)):
    get_or_404(session, SchoolClass, class_id)
    return session.query(BookDistribution).filter_by(class_id=class_id).order_by(BookDistribution.student_id, BookDistribution.subject_id).all()


@app.put("/book-distributions/{distribution_id}", response_model=DistributionOut)
def update_distribution(distribution_id: int, x: DistributionIn, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, x.class_id)
    student = get_or_404(session, Student, x.student_id)
    subject = get_or_404(session, Subject, x.subject_id)
    if student.class_id != cls.id or subject.class_id != cls.id:
        raise HTTPException(400, "all distribution references must belong to the same class")
    return patch_object(session, get_or_404(session, BookDistribution, distribution_id), x)


@app.delete("/book-distributions/{distribution_id}")
def delete_distribution(distribution_id: int, session: Session = Depends(db)):
    obj = get_or_404(session, BookDistribution, distribution_id)
    session.delete(obj)
    session.commit()
    return {"deleted": True, "id": distribution_id}


# ---------------------------------------------------------------------------
# Workbook-equivalent reports / views.  None of these uses Excel at runtime.
# ---------------------------------------------------------------------------
@app.get("/students/{student_id}/result")
def get_student_result(student_id: int, session: Session = Depends(db)):
    student = get_or_404(session, Student, student_id)
    cls = get_or_404(session, SchoolClass, student.class_id)
    return _student_engine_result(session, student, cls)


@app.get("/classes/{class_id}/results")
def get_class_results(class_id: int, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    results = _class_results(session, cls)
    return {"class_id": class_id, "students": results, "summary": class_summary(results)}


@app.get("/classes/{class_id}/compact-register")
def compact_register(class_id: int, session: Session = Depends(db)):
    """Equivalent to «فهرست جدول»: one compact row per student."""
    cls = get_or_404(session, SchoolClass, class_id)
    rows = []
    for st, result in zip(
        session.query(Student).filter_by(class_id=class_id).order_by(Student.attendance_no.is_(None), Student.attendance_no, Student.id).all(),
        _class_results(session, cls),
    ):
        rows.append(
            {
                "attendance_no": st.attendance_no,
                "student_id": st.id,
                "name": st.name,
                "father": st.father,
                "grandfather": st.grandfather,
                "tazkira": st.tazkira,
                "base_number": st.base_number,
                "mid_average": result["mid_average"],
                "annual_average": result["final_average"],
                "mid_grade": result["mid_grade"],
                "annual_grade": result["annual_grade"],
                "annual_result": result["annual_result"],
                "annual_absent": result["attendance"].get("annual", {}).get("absent", 0),
            }
        )
    return {"class_id": class_id, "rows": rows}


@app.get("/classes/{class_id}/subject-register")
def subject_register(class_id: int, session: Session = Depends(db)):
    """Equivalent to «فهرست مضمونوار»: dynamic columns per active subject."""
    cls = get_or_404(session, SchoolClass, class_id)
    students = session.query(Student).filter_by(class_id=class_id).order_by(Student.attendance_no.is_(None), Student.attendance_no, Student.id).all()
    results = [_student_engine_result(session, st, cls) for st in students]
    subjects = session.query(Subject).filter(Subject.class_id == class_id, Subject.active.is_(True), Subject.include_in_results.is_(True)).order_by(Subject.order_index, Subject.id).all()
    rows = []
    for result in results:
        by = {item["subject_id"]: item for item in result["subject_results"]}
        rows.append(
            {
                "attendance_no": result["attendance_no"],
                "student_id": result["student_id"],
                "student_name": result["student_name"],
                "subjects": {str(sub.id): {"name": sub.name, "mid": by.get(sub.id, {}).get("mid"), "annual": by.get(sub.id, {}).get("annual"), "final": by.get(sub.id, {}).get("final")} for sub in subjects},
                "final_sum": result["final_sum"],
                "final_average": result["final_average"],
                "annual_result": result["annual_result"],
                "annual_grade": result["annual_grade"],
                "attendance": result["attendance"],
            }
        )
    return {"class_id": class_id, "subjects": [SubjectOut.model_validate(s).model_dump() for s in subjects], "rows": rows}


@app.get("/classes/{class_id}/notice-cards")
def notice_cards(class_id: int, session: Session = Depends(db)):
    """Equivalent to «اطلاع نامه»: one generated notice/report object per student."""
    cls = get_or_404(session, SchoolClass, class_id)
    school = _school_for_class(session, cls)
    cards = []
    for st in session.query(Student).filter_by(class_id=class_id).order_by(Student.attendance_no.is_(None), Student.attendance_no, Student.id).all():
        result = _student_engine_result(session, st, cls)
        cards.append(
            {
                "school": SchoolOut.model_validate(school).model_dump(),
                "class": ClassOut.model_validate(cls).model_dump(),
                "student": StudentOut.model_validate(st).model_dump(),
                "result": result,
                "message": result["message"],
            }
        )
    return cards


@app.get("/students/{student_id}/report-card")
def report_card(student_id: int, session: Session = Depends(db)):
    student = get_or_404(session, Student, student_id)
    cls = get_or_404(session, SchoolClass, student.class_id)
    school = _school_for_class(session, cls)
    result = _student_engine_result(session, student, cls)
    approvals = session.query(Approval).filter_by(class_id=cls.id).order_by(Approval.id).all()
    return {
        "school": SchoolOut.model_validate(school).model_dump(),
        "class": ClassOut.model_validate(cls).model_dump(),
        "student": StudentOut.model_validate(student).model_dump(),
        "result": result,
        "message": result["message"],
        "approvals": [ApprovalOut.model_validate(a).model_dump() for a in approvals],
    }


@app.get("/classes/{class_id}/passing-list")
def passing_list(class_id: int, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    return [x for x in _class_results(session, cls) if x["annual_result"] == "ارتقا صنف"]


@app.get("/classes/{class_id}/conditional-list")
def conditional_list(class_id: int, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    return [x for x in _class_results(session, cls) if x["annual_result"] in {"مشروط", "معذرتی", "سه پارچه"}]


@app.get("/classes/{class_id}/failed-or-banned-list")
def failed_or_banned_list(class_id: int, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    return [x for x in _class_results(session, cls) if x["annual_result"] in {"تکرار صنف", "محروم", "سه پارچه"}]


@app.get("/classes/{class_id}/recent-summary")
def recent_summary(class_id: int, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    results = _class_results(session, cls)
    approvals = session.query(Approval).filter_by(class_id=class_id).order_by(Approval.id).all()
    return {
        "class_id": class_id,
        "summary": class_summary(results),
        "approvals": [ApprovalOut.model_validate(a).model_dump() for a in approvals],
    }


@app.get("/classes/{class_id}/approval-summary")
def approval_summary(class_id: int, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    school = _school_for_class(session, cls)
    return {
        "class": ClassOut.model_validate(cls).model_dump(),
        "approvals": [ApprovalOut.model_validate(a).model_dump() for a in session.query(Approval).filter_by(class_id=class_id).order_by(Approval.id).all()],
        "staff": {
            "teacher": cls.teacher_name,
            "principal": school.principal_name,
            "manager": school.manager_name,
        },
    }


@app.get("/classes/{class_id}/cover")
def class_cover(class_id: int, session: Session = Depends(db)):
    """Equivalent to the workbook cover sheet («پوش جدول»)."""
    cls = get_or_404(session, SchoolClass, class_id)
    school = _school_for_class(session, cls)
    year = get_or_404(session, AcademicYear, cls.academic_year_id) if cls.academic_year_id else None
    return {
        "school": SchoolOut.model_validate(school).model_dump(),
        "class": ClassOut.model_validate(cls).model_dump(),
        "academic_year": AcademicYearOut.model_validate(year).model_dump() if year else None,
        "teacher": cls.teacher_name,
    }


@app.get("/classes/{class_id}/book-distribution-register")
def book_distribution_register(class_id: int, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    subjects = session.query(Subject).filter(Subject.class_id == class_id, Subject.active.is_(True)).order_by(Subject.order_index, Subject.id).all()
    students = session.query(Student).filter_by(class_id=class_id).order_by(Student.attendance_no.is_(None), Student.attendance_no, Student.id).all()
    distributions = session.query(BookDistribution).filter_by(class_id=class_id).all()
    by = {(d.student_id, d.subject_id): d for d in distributions}
    rows = []
    for st in students:
        annual_result = _student_engine_result(session, st, cls)["annual_result"]
        rows.append(
            {
                "student_id": st.id,
                "attendance_no": st.attendance_no,
                "student_name": st.name,
                "result": annual_result,
                "subjects": {
                    str(sub.id): {
                        "subject_name": sub.name,
                        "delivered": bool(by.get((st.id, sub.id)) and by[(st.id, sub.id)].delivered),
                        "signed": bool(by.get((st.id, sub.id)) and by[(st.id, sub.id)].signed),
                        "quantity": int(by[(st.id, sub.id)].quantity) if (st.id, sub.id) in by else 0,
                    }
                    for sub in subjects
                },
            }
        )
    return {"class_id": class_id, "subjects": [SubjectOut.model_validate(s).model_dump() for s in subjects], "rows": rows}


@app.get("/classes/{class_id}/dashboard")
def dashboard(class_id: int, session: Session = Depends(db)):
    cls = get_or_404(session, SchoolClass, class_id)
    results = _class_results(session, cls)
    subjects = session.query(Subject).filter(Subject.class_id == class_id, Subject.active.is_(True), Subject.include_in_results.is_(True)).count()
    students = session.query(Student).filter_by(class_id=class_id).count()
    books = session.query(BookDistribution).filter_by(class_id=class_id).all()
    approvals = session.query(Approval).filter_by(class_id=class_id).all()
    return {
        "class_id": class_id,
        "students": students,
        "subjects": subjects,
        "summary": class_summary(results),
        "books": {
            "rows": len(books),
            "delivered": sum(1 for b in books if b.delivered),
            "signed": sum(1 for b in books if b.signed),
            "quantity": sum(b.quantity for b in books),
        },
        "approvals": {
            "total": len(approvals),
            "approved": sum(1 for a in approvals if a.approved),
        },
    }
