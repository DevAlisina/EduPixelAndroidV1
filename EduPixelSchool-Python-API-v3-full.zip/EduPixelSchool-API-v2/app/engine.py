"""Excel-independent school rules engine.

The workbook is a source for discovering rules only.  This module never opens
or evaluates an .xlsx file at runtime.  It implements the behaviour observed
across the workbook's calculation/report sheets in normalized Python data.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

EXCUSED_MID = "1"
EXCUSED_ANNUAL = "2"
THREE_PART = "3"

MSG_SUCCESS = (
    "به دلیل اینکه از روند آموزشی یک ساله نتیجه مثبت به‌ دست اورده اید، "
    "این موفقیت را به شما و خانواده محترم شما تبریک عرض میداریم، "
    "ارزومندیم که در عرصه علمی بیشتر بدرخشید...!"
)
MSG_NEED_EFFORT = "ناامید نشوید، تلاش کنید، حتماً موفق خواهید شد...!"

STATUS_MID_PASS = "موفق"
STATUS_MID_EFFORT = "تلاش بیشتر"
STATUS_MID_EXCUSED = "معذرتي"
STATUS_MID_ABSENT = "غایب"

STATUS_ANNUAL_PROMOTE = "ارتقا صنف"
STATUS_ANNUAL_REPEAT = "تکرار صنف"
STATUS_ANNUAL_CONDITIONAL = "مشروط"
STATUS_ANNUAL_EXCUSED = "معذرتی"
STATUS_ANNUAL_BANNED = "محروم"
STATUS_ANNUAL_THREE_PART = "سه پارچه"


@dataclass(frozen=True)
class ResultPolicy:
    """All grading/result thresholds are configurable per class."""

    max_absence_days: int = 56
    mid_min_subject: float = 16
    mid_avg_pass: float = 20
    annual_min_subject: float = 40
    annual_avg_pass: float = 50
    annual_repeat_below_count: int = 4
    mid_max_score: float = 40
    annual_max_score: float = 60
    final_max_score: float = 100
    mid_excused_code: str = EXCUSED_MID
    annual_excused_code: str = EXCUSED_ANNUAL
    three_part_code: str = THREE_PART

    def as_dict(self) -> dict[str, Any]:
        return {
            "max_absence_days": self.max_absence_days,
            "mid_min_subject": self.mid_min_subject,
            "mid_avg_pass": self.mid_avg_pass,
            "annual_min_subject": self.annual_min_subject,
            "annual_avg_pass": self.annual_avg_pass,
            "annual_repeat_below_count": self.annual_repeat_below_count,
            "mid_max_score": self.mid_max_score,
            "annual_max_score": self.annual_max_score,
            "final_max_score": self.final_max_score,
            "mid_excused_code": self.mid_excused_code,
            "annual_excused_code": self.annual_excused_code,
            "three_part_code": self.three_part_code,
        }

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any] | None) -> "ResultPolicy":
        if not data:
            return cls()
        base = cls().as_dict()
        for key in base:
            if key in data and data[key] is not None:
                base[key] = data[key]
        return cls(**base)


def _valid(values: Sequence[float | int | None]) -> list[float]:
    return [float(v) for v in values if v is not None and not isinstance(v, bool)]


def _average(values: Sequence[float]) -> float | None:
    return sum(values) / len(values) if values else None


def final_score(mid: float | None, annual: float | None) -> float | None:
    """Excel-equivalent final score: blank annual means blank; blank mid is zero."""
    if annual is None:
        return None
    return (0.0 if mid is None else float(mid)) + float(annual)


def mid_result(
    scores: Sequence[float | None],
    status: str | None,
    school_days: int,
    policy: ResultPolicy | None = None,
) -> str:
    policy = policy or ResultPolicy()
    if str(status or "") == policy.mid_excused_code:
        return STATUS_MID_EXCUSED
    values = _valid(scores)
    if not values:
        return STATUS_MID_ABSENT if school_days > 0 else ""
    average = _average(values) or 0.0
    if average < policy.mid_avg_pass or min(values) < policy.mid_min_subject:
        return STATUS_MID_EFFORT
    return STATUS_MID_PASS


def mid_grade(scores: Sequence[float | None], policy: ResultPolicy | None = None) -> str:
    policy = policy or ResultPolicy()
    values = _valid(scores)
    if not values:
        return ""
    if min(values) < policy.mid_min_subject:
        return "هـ"
    average = _average(values) or 0.0
    if average < 20:
        return "هـ"
    if average < 24:
        return "د"
    if average < 30:
        return "ج"
    if average < 36:
        return "ب"
    if average <= policy.mid_max_score:
        return "الف"
    return "اشتباه"


def annual_result(
    finals: Sequence[float | None],
    absent_days: int,
    status: str | None,
    school_days: int = 0,
    policy: ResultPolicy | None = None,
) -> str:
    """Replicate the annual-result decision order used by the workbook.

    Crucial workbook detail: with annual school-days > 0 and zero entered
    final marks, the result is "تکرار صنف", while with zero school-days it is
    blank.  Absence threshold and special status codes override this first.
    """
    policy = policy or ResultPolicy()
    if absent_days >= policy.max_absence_days:
        return STATUS_ANNUAL_BANNED
    code = str(status or "")
    if code == policy.annual_excused_code:
        return STATUS_ANNUAL_EXCUSED
    if code == policy.three_part_code:
        return STATUS_ANNUAL_THREE_PART

    values = _valid(finals)
    if not values:
        return STATUS_ANNUAL_REPEAT if school_days > 0 else ""

    average = _average(values) or 0.0
    if average < policy.annual_avg_pass:
        return STATUS_ANNUAL_REPEAT

    below_count = sum(1 for value in values if 0 <= value < policy.annual_min_subject)
    if below_count >= policy.annual_repeat_below_count:
        return STATUS_ANNUAL_REPEAT
    if all(value >= policy.annual_min_subject for value in values):
        return STATUS_ANNUAL_PROMOTE
    return STATUS_ANNUAL_CONDITIONAL


def annual_grade(
    finals: Sequence[float | None],
    result: str,
    policy: ResultPolicy | None = None,
) -> str:
    policy = policy or ResultPolicy()
    if result == STATUS_ANNUAL_REPEAT:
        return "هـ"
    if result in {STATUS_ANNUAL_BANNED, STATUS_ANNUAL_EXCUSED, STATUS_ANNUAL_THREE_PART, ""}:
        return ""
    values = _valid(finals)
    if not values:
        return ""
    average = _average(values) or 0.0
    if any(value < policy.annual_min_subject for value in values) or average < policy.annual_avg_pass:
        return "هـ"
    if average < 60:
        return "د"
    if average < 75:
        return "ج"
    if average < 90:
        return "ب"
    if average <= policy.final_max_score:
        return "الف"
    return "اشتباه"


def score_component_total(components: Mapping[str, Any] | None) -> float | None:
    """Sum numeric exam components, for the workbook's «شقه» style form."""
    if not components:
        return None
    numeric = [float(v) for v in components.values() if isinstance(v, (int, float)) and not isinstance(v, bool)]
    return sum(numeric) if numeric else None


def component_breakdown(components: Mapping[str, Any] | None) -> dict[str, Any]:
    components = dict(components or {})
    return {"components": components, "total": score_component_total(components)}


def student_result(
    *,
    subjects: Sequence[Mapping[str, Any]],
    scores: Mapping[int, Mapping[str, Any]],
    attendance: Mapping[str, Any],
    mid_status: str | None,
    annual_status: str | None,
    policy: ResultPolicy | None = None,
) -> dict[str, Any]:
    """Calculate one student's full academic/attendance result."""
    policy = policy or ResultPolicy()
    ordered = sorted(subjects, key=lambda x: (x.get("order_index", 0), x.get("id", 0)))

    subject_results: list[dict[str, Any]] = []
    mids: list[float | None] = []
    finals: list[float | None] = []
    for subject in ordered:
        sid = int(subject["id"])
        raw = scores.get(sid, {}) or {}
        mid = raw.get("mid")
        annual = raw.get("annual")
        final = final_score(mid, annual)
        mids.append(mid)
        finals.append(final)
        mid_components = raw.get("mid_components") or {}
        annual_components = raw.get("annual_components") or {}
        subject_results.append(
            {
                "subject_id": sid,
                "subject_name": subject.get("name", ""),
                "order_index": subject.get("order_index", 0),
                "mid": mid,
                "annual": annual,
                "final": final,
                "mid_components": mid_components,
                "annual_components": annual_components,
                "mid_component_total": score_component_total(mid_components),
                "annual_component_total": score_component_total(annual_components),
            }
        )

    mid_att = attendance.get("mid", {}) or {}
    annual_att = attendance.get("annual", {}) or {}
    mid_school_days = int(mid_att.get("school_days") or 0)
    annual_school_days = int(annual_att.get("school_days") or 0)
    annual_absent = int(annual_att.get("absent") or 0)

    mr = mid_result(mids, mid_status, mid_school_days, policy)
    mg = mid_grade(mids, policy)
    ar = annual_result(finals, annual_absent, annual_status, annual_school_days, policy)
    ag = annual_grade(finals, ar, policy)

    mid_values = _valid(mids)
    final_values = _valid(finals)
    return {
        "mid_result": mr,
        "mid_grade": mg,
        "annual_result": ar,
        "annual_grade": ag,
        "mid_sum": sum(mid_values) if mid_values else None,
        "mid_average": _average(mid_values),
        "final_sum": sum(final_values) if final_values else None,
        "final_average": _average(final_values),
        "below_40_count": sum(1 for value in final_values if 0 <= value < policy.annual_min_subject),
        "subject_count": len(ordered),
        "entered_mid_subject_count": len(mid_values),
        "entered_annual_subject_count": len([v for v in [s.get("annual") for s in subject_results] if v is not None]),
        "subject_results": subject_results,
        "attendance": {"mid": mid_att, "annual": annual_att},
    }


def class_summary(student_results: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Workbook-equivalent totals, generalized to any number of students."""
    total = len(student_results)
    mid_counts = {
        STATUS_MID_PASS: sum(1 for x in student_results if x.get("mid_result") == STATUS_MID_PASS),
        STATUS_MID_EFFORT: sum(1 for x in student_results if x.get("mid_result") == STATUS_MID_EFFORT),
        STATUS_MID_EXCUSED: sum(1 for x in student_results if x.get("mid_result") == STATUS_MID_EXCUSED),
        STATUS_MID_ABSENT: sum(1 for x in student_results if x.get("mid_result") == STATUS_MID_ABSENT),
    }
    annual_counts = {
        STATUS_ANNUAL_PROMOTE: sum(1 for x in student_results if x.get("annual_result") == STATUS_ANNUAL_PROMOTE),
        STATUS_ANNUAL_REPEAT: sum(1 for x in student_results if x.get("annual_result") == STATUS_ANNUAL_REPEAT),
        STATUS_ANNUAL_CONDITIONAL: sum(1 for x in student_results if x.get("annual_result") == STATUS_ANNUAL_CONDITIONAL),
        STATUS_ANNUAL_EXCUSED: sum(1 for x in student_results if x.get("annual_result") == STATUS_ANNUAL_EXCUSED),
        STATUS_ANNUAL_BANNED: sum(1 for x in student_results if x.get("annual_result") in {STATUS_ANNUAL_BANNED, STATUS_ANNUAL_THREE_PART}),
        STATUS_ANNUAL_THREE_PART: sum(1 for x in student_results if x.get("annual_result") == STATUS_ANNUAL_THREE_PART),
    }
    return {
        "total_enrolled": total,
        "mid_exam_included": total - mid_counts[STATUS_MID_ABSENT],
        "annual_exam_included": total - annual_counts[STATUS_ANNUAL_BANNED],
        "mid": mid_counts,
        "annual": annual_counts,
    }


def personalised_message(annual_result_text: str, mid_result_text: str | None = None) -> str:
    """The dynamic student message used by the notice/report sheet."""
    if annual_result_text == STATUS_ANNUAL_PROMOTE:
        return MSG_SUCCESS
    if annual_result_text in {STATUS_ANNUAL_REPEAT, STATUS_ANNUAL_CONDITIONAL}:
        return MSG_NEED_EFFORT
    if annual_result_text in {STATUS_ANNUAL_BANNED, STATUS_ANNUAL_EXCUSED, STATUS_ANNUAL_THREE_PART, ""}:
        return ""
    if mid_result_text == STATUS_MID_PASS:
        return MSG_SUCCESS
    if mid_result_text == STATUS_MID_EFFORT:
        return MSG_NEED_EFFORT
    return ""
