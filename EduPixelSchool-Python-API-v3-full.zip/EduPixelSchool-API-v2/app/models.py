from __future__ import annotations

import os

from sqlalchemy import Boolean, Date, ForeignKey, Integer, JSON, String, Float, UniqueConstraint, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker

DATABASE_URL = os.getenv("EDUPIXEL_DB_URL", "sqlite:///./edupixel.db")
engine_kwargs = {"connect_args": {"check_same_thread": False}} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, **engine_kwargs)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class School(Base):
    __tablename__ = "schools"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    province: Mapped[str | None] = mapped_column(String(100), nullable=True)
    district: Mapped[str | None] = mapped_column(String(100), nullable=True)
    manager_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    principal_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    academic_year_solar: Mapped[int | None] = mapped_column(Integer, nullable=True)
    academic_year_qamari: Mapped[int | None] = mapped_column(Integer, nullable=True)
    classes = relationship("SchoolClass", back_populates="school", cascade="all, delete-orphan")


class AcademicYear(Base):
    __tablename__ = "academic_years"
    id: Mapped[int] = mapped_column(primary_key=True)
    school_id: Mapped[int] = mapped_column(ForeignKey("schools.id", ondelete="CASCADE"))
    solar_year: Mapped[int] = mapped_column(Integer)
    qamari_year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    label: Mapped[str | None] = mapped_column(String(100), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    school = relationship("School")
    classes = relationship("SchoolClass", back_populates="academic_year", cascade="all, delete-orphan")
    __table_args__ = (UniqueConstraint("school_id", "solar_year", name="uq_year_per_school"),)


class SchoolClass(Base):
    __tablename__ = "classes"
    id: Mapped[int] = mapped_column(primary_key=True)
    school_id: Mapped[int] = mapped_column(ForeignKey("schools.id", ondelete="CASCADE"))
    academic_year_id: Mapped[int | None] = mapped_column(ForeignKey("academic_years.id", ondelete="SET NULL"), nullable=True)
    name: Mapped[str] = mapped_column(String(100))
    grade_level: Mapped[str | None] = mapped_column(String(50), nullable=True)
    section: Mapped[str | None] = mapped_column(String(50), nullable=True)
    teacher_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    max_absence: Mapped[int] = mapped_column(Integer, default=56)
    policy: Mapped[dict] = mapped_column(JSON, default=dict)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    school = relationship("School", back_populates="classes")
    academic_year = relationship("AcademicYear", back_populates="classes")
    subjects = relationship("Subject", back_populates="school_class", cascade="all, delete-orphan")
    students = relationship("Student", back_populates="school_class", cascade="all, delete-orphan")
    approvals = relationship("Approval", back_populates="school_class", cascade="all, delete-orphan")
    distributions = relationship("BookDistribution", back_populates="school_class", cascade="all, delete-orphan")
    __table_args__ = (UniqueConstraint("school_id", "academic_year_id", "name", name="uq_class_name_year"),)


class Subject(Base):
    __tablename__ = "subjects"
    id: Mapped[int] = mapped_column(primary_key=True)
    class_id: Mapped[int] = mapped_column(ForeignKey("classes.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(200))
    order_index: Mapped[int] = mapped_column(Integer, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    include_in_results: Mapped[bool] = mapped_column(Boolean, default=True)
    mid_max: Mapped[float] = mapped_column(Float, default=40)
    annual_max: Mapped[float] = mapped_column(Float, default=60)
    components_schema: Mapped[dict] = mapped_column(JSON, default=dict)
    school_class = relationship("SchoolClass", back_populates="subjects")
    scores = relationship("Score", back_populates="subject", cascade="all, delete-orphan")
    distributions = relationship("BookDistribution", back_populates="subject", cascade="all, delete-orphan")
    __table_args__ = (UniqueConstraint("class_id", "name", name="uq_subject_name_per_class"),)


class Student(Base):
    __tablename__ = "students"
    id: Mapped[int] = mapped_column(primary_key=True)
    class_id: Mapped[int] = mapped_column(ForeignKey("classes.id", ondelete="CASCADE"))
    attendance_no: Mapped[int | None] = mapped_column(Integer, nullable=True)
    name: Mapped[str] = mapped_column(String(200))
    father: Mapped[str | None] = mapped_column(String(200), nullable=True)
    grandfather: Mapped[str | None] = mapped_column(String(200), nullable=True)
    base_number: Mapped[str | None] = mapped_column(String(100), nullable=True)
    tazkira: Mapped[str | None] = mapped_column(String(200), nullable=True)
    mid_status: Mapped[str | None] = mapped_column(String(20), nullable=True)
    annual_status: Mapped[str | None] = mapped_column(String(20), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    school_class = relationship("SchoolClass", back_populates="students")
    scores = relationship("Score", back_populates="student", cascade="all, delete-orphan")
    attendance = relationship("Attendance", back_populates="student", cascade="all, delete-orphan")
    distributions = relationship("BookDistribution", back_populates="student", cascade="all, delete-orphan")
    __table_args__ = (UniqueConstraint("class_id", "attendance_no", name="uq_attendance_no_per_class"),)


class Score(Base):
    __tablename__ = "scores"
    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"))
    subject_id: Mapped[int] = mapped_column(ForeignKey("subjects.id", ondelete="CASCADE"))
    mid: Mapped[float | None] = mapped_column(Float, nullable=True)
    annual: Mapped[float | None] = mapped_column(Float, nullable=True)
    mid_components: Mapped[dict] = mapped_column(JSON, default=dict)
    annual_components: Mapped[dict] = mapped_column(JSON, default=dict)
    note: Mapped[str | None] = mapped_column(String(500), nullable=True)
    student = relationship("Student", back_populates="scores")
    subject = relationship("Subject", back_populates="scores")
    __table_args__ = (UniqueConstraint("student_id", "subject_id", name="uq_score_student_subject"),)


class Attendance(Base):
    __tablename__ = "attendance"
    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"))
    period: Mapped[str] = mapped_column(String(20))  # midterm | annual
    school_days: Mapped[int] = mapped_column(Integer, default=0)
    present: Mapped[int] = mapped_column(Integer, default=0)
    absent: Mapped[int] = mapped_column(Integer, default=0)
    sick: Mapped[int] = mapped_column(Integer, default=0)
    leave: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str | None] = mapped_column(String(500), nullable=True)
    student = relationship("Student", back_populates="attendance")
    __table_args__ = (UniqueConstraint("student_id", "period", name="uq_attendance_period"),)


class Approval(Base):
    __tablename__ = "approvals"
    id: Mapped[int] = mapped_column(primary_key=True)
    class_id: Mapped[int] = mapped_column(ForeignKey("classes.id", ondelete="CASCADE"))
    role: Mapped[str] = mapped_column(String(100))
    person_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    note: Mapped[str | None] = mapped_column(String(500), nullable=True)
    approved: Mapped[bool] = mapped_column(Boolean, default=False)
    class_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    school_class = relationship("SchoolClass", back_populates="approvals")


class BookDistribution(Base):
    __tablename__ = "book_distributions"
    id: Mapped[int] = mapped_column(primary_key=True)
    class_id: Mapped[int] = mapped_column(ForeignKey("classes.id", ondelete="CASCADE"))
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"))
    subject_id: Mapped[int] = mapped_column(ForeignKey("subjects.id", ondelete="CASCADE"))
    quantity: Mapped[int] = mapped_column(Integer, default=1)
    delivered: Mapped[bool] = mapped_column(Boolean, default=False)
    signed: Mapped[bool] = mapped_column(Boolean, default=False)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    school_class = relationship("SchoolClass", back_populates="distributions")
    student = relationship("Student", back_populates="distributions")
    subject = relationship("Subject", back_populates="distributions")
    __table_args__ = (UniqueConstraint("student_id", "subject_id", name="uq_distribution_student_subject"),)


def reset_database() -> None:
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)


Base.metadata.create_all(bind=engine)
