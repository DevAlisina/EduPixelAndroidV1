from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class SchoolIn(BaseModel):
    name: str
    province: str | None = None
    district: str | None = None
    manager_name: str | None = None
    principal_name: str | None = None
    academic_year_solar: int | None = None
    academic_year_qamari: int | None = None


class SchoolOut(SchoolIn, ORM):
    id: int


class AcademicYearIn(BaseModel):
    school_id: int
    solar_year: int
    qamari_year: int | None = None
    label: str | None = None
    is_active: bool = True


class AcademicYearOut(AcademicYearIn, ORM):
    id: int


class ClassIn(BaseModel):
    school_id: int
    academic_year_id: int | None = None
    name: str
    grade_level: str | None = None
    section: str | None = None
    teacher_name: str | None = None
    max_absence: int = Field(default=56, ge=0)
    policy: dict[str, Any] = Field(default_factory=dict)
    notes: str | None = None


class ClassOut(ClassIn, ORM):
    id: int


class SubjectIn(BaseModel):
    class_id: int
    name: str
    order_index: int = 0
    active: bool = True
    include_in_results: bool = True
    mid_max: float = Field(default=40, ge=0)
    annual_max: float = Field(default=60, ge=0)
    # Example: {"midterm":{"homework":5,"activity":5,"oral":10,"written":20},
    #           "annual":{"homework":10,"activity":10,"oral":10,"written":30}}
    components_schema: dict[str, Any] = Field(default_factory=dict)


class SubjectOut(SubjectIn, ORM):
    id: int


class StudentIn(BaseModel):
    class_id: int
    attendance_no: int | None = Field(default=None, ge=1)
    name: str
    father: str | None = None
    grandfather: str | None = None
    base_number: str | None = None
    tazkira: str | None = None
    mid_status: str | None = None
    annual_status: str | None = None
    notes: str | None = None


class StudentOut(StudentIn, ORM):
    id: int


class ScoreIn(BaseModel):
    student_id: int
    subject_id: int
    mid: float | None = Field(default=None, ge=0)
    annual: float | None = Field(default=None, ge=0)
    mid_components: dict[str, Any] = Field(default_factory=dict)
    annual_components: dict[str, Any] = Field(default_factory=dict)
    note: str | None = None


class ScoreOut(ScoreIn, ORM):
    id: int


class ScoreBulkIn(BaseModel):
    items: list[ScoreIn] = Field(min_length=1)


class AttendanceIn(BaseModel):
    period: Literal["midterm", "annual"]
    school_days: int = Field(default=0, ge=0)
    present: int = Field(default=0, ge=0)
    absent: int = Field(default=0, ge=0)
    sick: int = Field(default=0, ge=0)
    leave: int = Field(default=0, ge=0)
    note: str | None = None


class AttendanceOut(AttendanceIn, ORM):
    id: int
    student_id: int


class AttendanceBulkItem(AttendanceIn):
    student_id: int


class AttendanceBulkIn(BaseModel):
    items: list[AttendanceBulkItem] = Field(min_length=1)


class ApprovalIn(BaseModel):
    class_id: int
    role: str
    person_name: str | None = None
    note: str | None = None
    approved: bool = False
    class_type: str | None = None


class ApprovalOut(ApprovalIn, ORM):
    id: int


class DistributionIn(BaseModel):
    class_id: int
    student_id: int
    subject_id: int
    quantity: int = Field(default=1, ge=0)
    delivered: bool = False
    signed: bool = False
    notes: str | None = None


class DistributionOut(DistributionIn, ORM):
    id: int
